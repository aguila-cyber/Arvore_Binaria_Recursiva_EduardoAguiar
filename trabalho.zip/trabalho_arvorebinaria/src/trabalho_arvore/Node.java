package trabalho_arvore;

public class Node {
    int valor;
    Node esquerda;
    Node direita;

    public Node(int valor) {
        this.valor = valor;
        this.esquerda = null;
        this.direita = null;
    }

    public String toString() {
        return String.valueOf(valor);
    }
}
	  
