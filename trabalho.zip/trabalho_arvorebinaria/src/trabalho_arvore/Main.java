package trabalho_arvore;

import java.util.List;

public class Main {
    public static void main(String[] args) {

    	
        ArvoreBinaria arvore = new ArvoreBinaria();


        int[] valores = {50, 30, 70, 20, 40, 60, 80};
        for (int v : valores) {
            arvore.inserir(v);
        }


        System.out.println("Buscar 40: " + arvore.buscar(40));
        System.out.println("Buscar 25: " + arvore.buscar(25));


        List<Integer> pre = arvore.preOrdem();
        List<Integer> em = arvore.emOrdem();
        List<Integer> pos = arvore.posOrdem();

        System.out.println("Pré-ordem: " + pre);
        System.out.println("Em-ordem: " + em);
        System.out.println("Pós-ordem: " + pos);
    }
}